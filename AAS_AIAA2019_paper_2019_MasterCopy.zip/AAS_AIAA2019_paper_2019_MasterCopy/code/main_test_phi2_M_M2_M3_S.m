% MAIN 
% Junette Hsin 
% Mohammad Ayoubi 

% clear; 
% close all; 
inputs                          % Creates initial, final, and sun vectors 

disp('***') 

disp('phi2_M') 
phi2 = phi2_M; 
steering_profile                % Computes vel, accel, quat, torque profiles 
post_processing                 % Generates gyrostat unit sphere plot 

disp('phi2_M2') 
phi2 = phi2_M2; 
steering_profile                % Computes vel, accel, quat, torque profiles 
post_processing                 % Generates gyrostat unit sphere plot 

disp('phi2_M3') 
phi2 = phi2_M3; 
steering_profile                % Computes vel, accel, quat, torque profiles 
post_processing                 % Generates gyrostat unit sphere plot 

disp('phi2_S') 
phi2 = phi2_S; 
steering_profile                % Computes vel, accel, quat, torque profiles 
post_processing                 % Generates gyrostat unit sphere plot 


disp('phi2_eq6_atan2') 
    top = dot(S_G0, cross(P1_G0, S_PiPf_G0)); 
    bot = dot(P1_G0, S_PiPf_G0) - dot(S_G0, P1_G0)*dot(S_G0, S_PiPf_G0);
    phi2_eq6_atan2 = 2*abs( atan2 ( top, bot ) ); 
phi2 = phi2_eq6_atan2; 
steering_profile                % Computes vel, accel, quat, torque profiles 
post_processing                 % Generates gyrostat unit sphere plot 

%%
disp('phi2_eq7_atan2') 
    top = sin(alpha)*sin(ep); 
    bot = cos(ep) - cos(theta)*cos(alpha); 
    phi2_eq7_atan2 = 2*abs( atan2 ( top, bot ) ); 
phi2 = phi2_eq7_atan2; 
steering_profile                % Computes vel, accel, quat, torque profiles 
post_processing                 % Generates gyrostat unit sphere plot 
