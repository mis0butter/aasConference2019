% MAIN 
% Junette Hsin 
% Mohammad Ayoubi 

% clear; 
% close all; 
inputs                          % Creates initial, final, and sun vectors 

disp('***') 

disp('phi2_M') 
phi2 = phi2_M; 
steering_profile                % Computes vel, accel, quat, torque profiles 
post_processing                 % Generates gyrostat unit sphere plot 

disp('phi2_M2') 
phi2 = phi2_M2; 
steering_profile                % Computes vel, accel, quat, torque profiles 
post_processing                 % Generates gyrostat unit sphere plot 

disp('phi2_M3') 
phi2 = phi2_M3; 
steering_profile                % Computes vel, accel, quat, torque profiles 
post_processing                 % Generates gyrostat unit sphere plot 

disp('phi2_S') 
phi2 = phi2_S; 
steering_profile                % Computes vel, accel, quat, torque profiles 
post_processing                 % Generates gyrostat unit sphere plot 